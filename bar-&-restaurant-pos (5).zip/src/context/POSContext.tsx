import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Product,
  ProductVariant,
  OrderItem,
  OrderType,
  HeldBill,
  Bill,
  KOT,
  SystemSettings,
  Category,
  Company,
  Room,
  RoomBooking
} from '../types.ts';
import { fetchApi } from '../lib/api.ts';
import { printThermalReceipt, printRoomBookingTicket } from '../lib/printEngine.ts';
import { useAuth } from './AuthContext.tsx';

interface POSContextType {
  products: Product[];
  categories: Category[];
  companies: Company[];
  rooms: Room[];
  roomBookings: RoomBooking[];
  settings: SystemSettings | null;
  isLoading: boolean;
  selectedCategory: string; // 'all' or category id or 'bar'/'food'/'drinks' or 'rooms'
  searchQuery: string;
  selectedCompany: string; // 'all' or company id
  cart: OrderItem[];
  orderType: OrderType;
  tableNumber: string;
  customerName: string;
  customerPhone: string;
  notes: string;
  discountPercentage: number;
  discountAmount: number;
  activeHeldBillId: string | null;
  heldBills: HeldBill[];
  recentCompletedBill: Bill | null;
  
  // Modals & Active Selections
  isVariantModalOpen: boolean;
  selectedProductForVariant: Product | null;
  isPaymentModalOpen: boolean;
  isHeldBillsModalOpen: boolean;
  isReceiptModalOpen: boolean;
  isKOTModalOpen: boolean;
  isBookingModalOpen: boolean;
  selectedRoomForBooking: Room | null;
  recentBookingTicket: RoomBooking | null;
  isBookingTicketModalOpen: boolean;
  
  // Computed Totals
  subtotal: number;
  totalDiscount: number;
  serviceCharge: number;
  tax: number;
  grandTotal: number;
  totalItemsCount: number;

  // Actions
  setSelectedCategory: (cat: string) => void;
  setSearchQuery: (query: string) => void;
  setSelectedCompany: (comp: string) => void;
  setOrderType: (type: OrderType) => void;
  setTableNumber: (table: string) => void;
  setCustomerName: (name: string) => void;
  setCustomerPhone: (phone: string) => void;
  setNotes: (notes: string) => void;
  setDiscountPercentage: (pct: number) => void;
  setDiscountAmount: (amount: number) => void;
  
  // Cart Actions
  openVariantModal: (product: Product) => void;
  closeVariantModal: () => void;
  addToCart: (product: Product, variant: ProductVariant, quantity?: number, itemNotes?: string) => void;
  updateCartQuantity: (variantId: string, quantity: number) => void;
  removeFromCart: (variantId: string) => void;
  clearCart: () => void;
  
  // Hold & KOT & Checkout Actions
  setIsPaymentModalOpen: (open: boolean) => void;
  setIsHeldBillsModalOpen: (open: boolean) => void;
  setIsReceiptModalOpen: (open: boolean) => void;
  setIsKOTModalOpen: (open: boolean) => void;
  holdCurrentBill: () => Promise<HeldBill>;
  loadHeldBill: (heldBill: HeldBill) => void;
  deleteHeldBill: (heldBillId: string) => Promise<void>;
  createKOT: () => Promise<KOT>;
  completeCheckout: (paymentMethod: Bill['paymentMethod'], amountReceived: number, paymentDetails?: any) => Promise<Bill>;
  refreshProducts: () => Promise<void>;
  refreshHeldBills: () => Promise<void>;
  handleBarcodeScan: (barcode: string) => boolean;

  // Room Management & Booking Actions
  openRoomBookingModal: (room?: Room | null) => void;
  closeRoomBookingModal: () => void;
  openBookingTicketModal: (booking: RoomBooking) => void;
  closeBookingTicketModal: () => void;
  refreshRooms: () => Promise<void>;
  refreshRoomBookings: () => Promise<void>;
  createRoomBooking: (payload: any) => Promise<RoomBooking>;
  checkoutRoomBooking: (bookingId: string, checkoutData: any) => Promise<RoomBooking>;
  cancelRoomBooking: (bookingId: string, reason?: string) => Promise<void>;
  addRoomPayment: (bookingId: string, paymentData: any) => Promise<RoomBooking>;
  createRoom: (roomData: Partial<Room>) => Promise<Room>;
  updateRoom: (roomId: string, roomData: Partial<Room>) => Promise<Room>;
  deleteRoom: (roomId: string) => Promise<void>;
  printRoomTicket: (booking: RoomBooking) => Promise<boolean>;
}

const POSContext = createContext<POSContextType | undefined>(undefined);

export const POSProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [companies, setCompanies] = useState<Company[]>([]);
  const [rooms, setRooms] = useState<Room[]>([]);
  const [roomBookings, setRoomBookings] = useState<RoomBooking[]>([]);
  const [settings, setSettings] = useState<SystemSettings | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // POS Filters & Inputs
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCompany, setSelectedCompany] = useState<string>('all');

  // Cart & Order State
  const [cart, setCart] = useState<OrderItem[]>([]);
  const [orderType, setOrderType] = useState<OrderType>('dine_in');
  const [tableNumber, setTableNumber] = useState<string>('');
  const [customerName, setCustomerName] = useState<string>('');
  const [customerPhone, setCustomerPhone] = useState<string>('');
  const [notes, setNotes] = useState<string>('');
  const [discountPercentage, setDiscountPercentage] = useState<number>(0);
  const [discountAmount, setDiscountAmount] = useState<number>(0);
  const [activeHeldBillId, setActiveHeldBillId] = useState<string | null>(null);

  // Held Bills & Completed Bills
  const [heldBills, setHeldBills] = useState<HeldBill[]>([]);
  const [recentCompletedBill, setRecentCompletedBill] = useState<Bill | null>(null);

  // Modals
  const [isVariantModalOpen, setIsVariantModalOpen] = useState<boolean>(false);
  const [selectedProductForVariant, setSelectedProductForVariant] = useState<Product | null>(null);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState<boolean>(false);
  const [isHeldBillsModalOpen, setIsHeldBillsModalOpen] = useState<boolean>(false);
  const [isReceiptModalOpen, setIsReceiptModalOpen] = useState<boolean>(false);
  const [isKOTModalOpen, setIsKOTModalOpen] = useState<boolean>(false);

  // Room Modals & State
  const [isBookingModalOpen, setIsBookingModalOpen] = useState<boolean>(false);
  const [selectedRoomForBooking, setSelectedRoomForBooking] = useState<Room | null>(null);
  const [recentBookingTicket, setRecentBookingTicket] = useState<RoomBooking | null>(null);
  const [isBookingTicketModalOpen, setIsBookingTicketModalOpen] = useState<boolean>(false);

  // Load Initial Data
  const loadData = async () => {
    try {
      setIsLoading(true);
      const [prodsData, catsData, compsData, settsData, heldData, roomsData, bookingsData] = await Promise.all([
        fetchApi<Product[]>('/products'),
        fetchApi<Category[]>('/categories'),
        fetchApi<Company[]>('/companies'),
        fetchApi<SystemSettings>('/settings'),
        fetchApi<HeldBill[]>('/orders/held'),
        fetchApi<Room[]>('/rooms'),
        fetchApi<RoomBooking[]>('/room-bookings'),
      ]);

      setProducts(prodsData || []);
      setCategories(catsData || []);
      setCompanies(compsData || []);
      setSettings(settsData || null);
      setHeldBills(heldData || []);
      setRooms(roomsData || []);
      setRoomBookings(bookingsData || []);
    } catch (err) {
      console.error('Failed to load POS data:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (user) {
      loadData();
    }
  }, [user]);

  const refreshProducts = async () => {
    const prods = await fetchApi<Product[]>('/products');
    setProducts(prods || []);
  };

  const refreshHeldBills = async () => {
    const held = await fetchApi<HeldBill[]>('/orders/held');
    setHeldBills(held || []);
  };

  const refreshRooms = async () => {
    const rData = await fetchApi<Room[]>('/rooms');
    setRooms(rData || []);
  };

  const refreshRoomBookings = async () => {
    const bData = await fetchApi<RoomBooking[]>('/room-bookings');
    setRoomBookings(bData || []);
  };

  // Room Booking Modal Triggers
  const openRoomBookingModal = (room?: Room | null) => {
    setSelectedRoomForBooking(room || null);
    setIsBookingModalOpen(true);
  };

  const closeRoomBookingModal = () => {
    setIsBookingModalOpen(false);
    setSelectedRoomForBooking(null);
  };

  const openBookingTicketModal = (booking: RoomBooking) => {
    setRecentBookingTicket(booking);
    setIsBookingTicketModalOpen(true);
  };

  const closeBookingTicketModal = () => {
    setIsBookingTicketModalOpen(false);
    setRecentBookingTicket(null);
  };

  // Room CRUD Actions
  const createRoom = async (roomData: Partial<Room>): Promise<Room> => {
    const newRoom = await fetchApi<Room>('/rooms', {
      method: 'POST',
      body: JSON.stringify(roomData),
    });
    await refreshRooms();
    return newRoom;
  };

  const updateRoom = async (roomId: string, roomData: Partial<Room>): Promise<Room> => {
    const updated = await fetchApi<Room>(`/rooms/${roomId}`, {
      method: 'PUT',
      body: JSON.stringify(roomData),
    });
    await refreshRooms();
    return updated;
  };

  const deleteRoom = async (roomId: string): Promise<void> => {
    await fetchApi(`/rooms/${roomId}`, {
      method: 'DELETE',
    });
    await refreshRooms();
  };

  // Room Booking Actions
  const createRoomBooking = async (payload: any): Promise<RoomBooking> => {
    const res = await fetchApi<{ success: boolean; booking: RoomBooking; room: Room }>('/room-bookings', {
      method: 'POST',
      body: JSON.stringify(payload),
    });

    await refreshRooms();
    await refreshRoomBookings();
    
    // Set for ticket modal preview & auto print
    setRecentBookingTicket(res.booking);
    setIsBookingModalOpen(false);
    setIsBookingTicketModalOpen(true);

    if (settings?.autoPrintAfterPayment) {
      setTimeout(() => {
        printThermalReceipt(res.booking as any, settings).catch(() => {});
      }, 300);
    }

    return res.booking;
  };

  const checkoutRoomBooking = async (bookingId: string, checkoutData: any): Promise<RoomBooking> => {
    const res = await fetchApi<{ success: boolean; booking: RoomBooking; room: Room }>(`/room-bookings/${bookingId}/checkout`, {
      method: 'PUT',
      body: JSON.stringify(checkoutData),
    });

    await refreshRooms();
    await refreshRoomBookings();
    return res.booking;
  };

  const cancelRoomBooking = async (bookingId: string, reason?: string): Promise<void> => {
    await fetchApi(`/room-bookings/${bookingId}/cancel`, {
      method: 'PUT',
      body: JSON.stringify({ reason }),
    });

    await refreshRooms();
    await refreshRoomBookings();
  };

  const addRoomPayment = async (bookingId: string, paymentData: any): Promise<RoomBooking> => {
    const res = await fetchApi<{ success: boolean; booking: RoomBooking }>(`/room-bookings/${bookingId}/payment`, {
      method: 'POST',
      body: JSON.stringify(paymentData),
    });

    await refreshRoomBookings();
    return res.booking;
  };

  const printRoomTicket = async (booking: RoomBooking): Promise<boolean> => {
    const matchedRoom = rooms.find(r => r.id === booking.roomId) || null;
    return printRoomBookingTicket(booking, matchedRoom, settings);
  };

  // Calculations
  const subtotal = cart.reduce((sum, item) => sum + (item.unitPrice * item.quantity), 0);
  
  // Calculate discount (percentage takes precedence if > 0, otherwise fixed amount)
  let computedDiscount = 0;
  if (discountPercentage > 0) {
    computedDiscount = (subtotal * discountPercentage) / 100;
  } else if (discountAmount > 0) {
    computedDiscount = Math.min(discountAmount, subtotal);
  }

  const taxableAmount = Math.max(0, subtotal - computedDiscount);
  const serviceChargeRate = settings?.serviceChargeRate || 0;
  const serviceCharge = (taxableAmount * serviceChargeRate) / 100;

  const taxRate = settings?.taxRate || 0;
  const tax = (taxableAmount * taxRate) / 100;

  const grandTotal = Math.round(taxableAmount + serviceCharge + tax);
  const totalItemsCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  // Cart Operations
  const openVariantModal = (product: Product) => {
    // If only 1 variant exists, directly add it
    if (product.variants.length === 1) {
      addToCart(product, product.variants[0], 1);
    } else {
      setSelectedProductForVariant(product);
      setIsVariantModalOpen(true);
    }
  };

  const closeVariantModal = () => {
    setIsVariantModalOpen(false);
    setSelectedProductForVariant(null);
  };

  const addToCart = (
    product: Product,
    variant: ProductVariant,
    quantity: number = 1,
    itemNotes?: string
  ) => {
    setCart(prevCart => {
      const existingIndex = prevCart.findIndex(item => item.variantId === variant.id);

      if (existingIndex > -1) {
        const updated = [...prevCart];
        const currentQty = updated[existingIndex].quantity;
        const newQty = currentQty + quantity;
        const unitPrice = variant.sellingPrice;
        const lineTotal = newQty * unitPrice;

        updated[existingIndex] = {
          ...updated[existingIndex],
          quantity: newQty,
          total: lineTotal,
          notes: itemNotes || updated[existingIndex].notes,
        };
        return updated;
      } else {
        const unitPrice = variant.sellingPrice;
        const newItem: OrderItem = {
          id: `item-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
          productId: product.id,
          productName: product.name,
          variantId: variant.id,
          size: variant.size,
          unitPrice,
          costPrice: variant.costPrice,
          quantity,
          discount: 0,
          tax: 0,
          total: unitPrice * quantity,
          notes: itemNotes,
          isKitchenItem: product.isKitchenItem,
        };
        return [...prevCart, newItem];
      }
    });

    closeVariantModal();
  };

  const updateCartQuantity = (variantId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(variantId);
      return;
    }

    setCart(prevCart =>
      prevCart.map(item => {
        if (item.variantId === variantId) {
          return {
            ...item,
            quantity,
            total: item.unitPrice * quantity,
          };
        }
        return item;
      })
    );
  };

  const removeFromCart = (variantId: string) => {
    setCart(prevCart => prevCart.filter(item => item.variantId !== variantId));
  };

  const clearCart = () => {
    setCart([]);
    setDiscountPercentage(0);
    setDiscountAmount(0);
    setNotes('');
    setTableNumber('');
    setCustomerName('');
    setCustomerPhone('');
    setActiveHeldBillId(null);
  };

  // Hold Bill
  const holdCurrentBill = async (): Promise<HeldBill> => {
    if (cart.length === 0) {
      throw new Error('Cart is empty. Add items before holding.');
    }

    const payload = {
      items: cart,
      orderType,
      tableNumber,
      customerName,
      customerPhone,
      subtotal,
      discount: computedDiscount,
      discountPercentage,
      tax,
      grandTotal,
      notes,
      existingHeldId: activeHeldBillId || undefined,
    };

    const savedHeld = await fetchApi<HeldBill>('/orders/hold', {
      method: 'POST',
      body: JSON.stringify(payload),
    });

    await refreshHeldBills();
    clearCart();
    return savedHeld;
  };

  const loadHeldBill = (heldBill: HeldBill) => {
    setCart(heldBill.items);
    setOrderType(heldBill.orderType);
    setTableNumber(heldBill.tableNumber || '');
    setCustomerName(heldBill.customerName || '');
    setCustomerPhone(heldBill.customerPhone || '');
    setNotes(heldBill.notes || '');
    setDiscountPercentage(heldBill.discountPercentage || 0);
    setDiscountAmount(heldBill.discountPercentage ? 0 : heldBill.discount || 0);
    setActiveHeldBillId(heldBill.id);
    setIsHeldBillsModalOpen(false);
  };

  const deleteHeldBill = async (heldBillId: string) => {
    await fetchApi(`/orders/held/${heldBillId}`, { method: 'DELETE' });
    if (activeHeldBillId === heldBillId) {
      setActiveHeldBillId(null);
    }
    await refreshHeldBills();
  };

  // Kitchen Order Ticket (KOT)
  const createKOT = async (): Promise<KOT> => {
    if (cart.length === 0) {
      throw new Error('Cart is empty. Cannot generate KOT.');
    }

    const payload = {
      items: cart,
      orderType,
      tableNumber: tableNumber || (orderType === 'bar_counter' ? 'Bar Counter' : 'Walk-in'),
      notes,
    };

    const kot = await fetchApi<KOT>('/kot', {
      method: 'POST',
      body: JSON.stringify(payload),
    });

    return kot;
  };

  // Checkout & Pay
  const completeCheckout = async (
    paymentMethod: Bill['paymentMethod'],
    amountReceived: number,
    paymentDetails?: any
  ): Promise<Bill> => {
    if (cart.length === 0) {
      throw new Error('Cart is empty. Cannot complete sale.');
    }

    const payload = {
      items: cart,
      orderType,
      tableNumber,
      customerName,
      customerPhone,
      subtotal,
      discount: computedDiscount,
      discountPercentage,
      tax,
      taxRate,
      serviceCharge,
      grandTotal,
      amountReceived,
      changeAmount: Math.max(0, amountReceived - grandTotal),
      paymentMethod,
      paymentDetails,
      notes,
      heldBillId: activeHeldBillId || undefined,
    };

    const completedBill = await fetchApi<Bill>('/bills/checkout', {
      method: 'POST',
      body: JSON.stringify(payload),
    });

    setRecentCompletedBill(completedBill);
    await refreshProducts();
    await refreshHeldBills();
    clearCart();
    setIsPaymentModalOpen(false);
    setIsReceiptModalOpen(true);

    if (settings?.autoPrintAfterPayment) {
      setTimeout(() => {
        printThermalReceipt(completedBill, settings).catch(err => {
          console.warn('Auto print thermal receipt failed:', err);
        });
      }, 300);
    }

    return completedBill;
  };

  // Barcode Scanner Listener Helper
  const handleBarcodeScan = (scannedCode: string): boolean => {
    if (!scannedCode) return false;
    const cleanCode = scannedCode.trim().toLowerCase();

    for (const p of products) {
      if (!p.isActive || p.isArchived) continue;
      for (const v of p.variants) {
        if (!v.isActive) continue;
        if (
          (v.barcode && v.barcode.toLowerCase() === cleanCode) ||
          (v.sku && v.sku.toLowerCase() === cleanCode)
        ) {
          addToCart(p, v, 1);
          return true;
        }
      }
    }
    return false;
  };

  return (
    <POSContext.Provider
      value={{
        products,
        categories,
        companies,
        rooms,
        roomBookings,
        settings,
        isLoading,
        selectedCategory,
        searchQuery,
        selectedCompany,
        cart,
        orderType,
        tableNumber,
        customerName,
        customerPhone,
        notes,
        discountPercentage,
        discountAmount,
        activeHeldBillId,
        heldBills,
        recentCompletedBill,
        isVariantModalOpen,
        selectedProductForVariant,
        isPaymentModalOpen,
        isHeldBillsModalOpen,
        isReceiptModalOpen,
        isKOTModalOpen,
        isBookingModalOpen,
        selectedRoomForBooking,
        recentBookingTicket,
        isBookingTicketModalOpen,
        subtotal,
        totalDiscount: computedDiscount,
        serviceCharge,
        tax,
        grandTotal,
        totalItemsCount,
        setSelectedCategory,
        setSearchQuery,
        setSelectedCompany,
        setOrderType,
        setTableNumber,
        setCustomerName,
        setCustomerPhone,
        setNotes,
        setDiscountPercentage,
        setDiscountAmount,
        openVariantModal,
        closeVariantModal,
        addToCart,
        updateCartQuantity,
        removeFromCart,
        clearCart,
        setIsPaymentModalOpen,
        setIsHeldBillsModalOpen,
        setIsReceiptModalOpen,
        setIsKOTModalOpen,
        holdCurrentBill,
        loadHeldBill,
        deleteHeldBill,
        createKOT,
        completeCheckout,
        refreshProducts,
        refreshHeldBills,
        handleBarcodeScan,
        openRoomBookingModal,
        closeRoomBookingModal,
        openBookingTicketModal,
        closeBookingTicketModal,
        refreshRooms,
        refreshRoomBookings,
        createRoomBooking,
        checkoutRoomBooking,
        cancelRoomBooking,
        addRoomPayment,
        createRoom,
        updateRoom,
        deleteRoom,
        printRoomTicket,
      }}
    >
      {children}
    </POSContext.Provider>
  );
};

export function usePOS() {
  const context = useContext(POSContext);
  if (!context) {
    throw new Error('usePOS must be used within a POSProvider');
  }
  return context;
}
