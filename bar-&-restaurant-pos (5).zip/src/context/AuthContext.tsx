import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, UserRole } from '../types.ts';
import { fetchApi } from '../lib/api.ts';

interface AuthContextType {
  user: User | null;
  token: string | null;
  isLoading: boolean;
  isSuperAdmin: boolean;
  isCashier: boolean;
  login: (
    credentialsOrUsername: string | { username?: string; password?: string; pin?: string },
    passwordArg?: string
  ) => Promise<void>;
  logout: () => Promise<void>;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('pos_user');
    return saved ? JSON.parse(saved) : null;
  });
  const [token, setToken] = useState<string | null>(() => localStorage.getItem('pos_auth_token'));
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    const handleAuthExpired = () => {
      setUser(null);
      setToken(null);
    };
    window.addEventListener('pos_auth_expired', handleAuthExpired);

    // Verify session
    if (token) {
      fetchApi<{ user: User }>('/auth/me')
        .then(data => {
          setUser(data.user);
          localStorage.setItem('pos_user', JSON.stringify(data.user));
        })
        .catch(() => {
          setUser(null);
          setToken(null);
          localStorage.removeItem('pos_auth_token');
          localStorage.removeItem('pos_user');
        })
        .finally(() => setIsLoading(false));
    } else {
      setIsLoading(false);
    }

    return () => {
      window.removeEventListener('pos_auth_expired', handleAuthExpired);
    };
  }, [token]);

  const login = async (
    credentialsOrUsername: string | { username?: string; password?: string; pin?: string },
    passwordArg?: string
  ) => {
    setIsLoading(true);
    try {
      let payload: { username?: string; password?: string; pin?: string };
      if (typeof credentialsOrUsername === 'string') {
        payload = {
          username: credentialsOrUsername,
          password: passwordArg || '',
        };
      } else {
        payload = credentialsOrUsername;
      }

      const data = await fetchApi<{ token: string; user: User }>('/auth/login', {
        method: 'POST',
        body: JSON.stringify(payload),
      });

      setToken(data.token);
      setUser(data.user);
      localStorage.setItem('pos_auth_token', data.token);
      localStorage.setItem('pos_user', JSON.stringify(data.user));
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    try {
      if (token) {
        await fetchApi('/auth/logout', { method: 'POST' }).catch(() => {});
      }
    } finally {
      setToken(null);
      setUser(null);
      localStorage.removeItem('pos_auth_token');
      localStorage.removeItem('pos_user');
    }
  };

  const refreshUser = async () => {
    if (token) {
      const data = await fetchApi<{ user: User }>('/auth/me');
      setUser(data.user);
      localStorage.setItem('pos_user', JSON.stringify(data.user));
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isLoading,
        isSuperAdmin: user?.role === 'super_admin',
        isCashier: user?.role === 'cashier',
        login,
        logout,
        refreshUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
