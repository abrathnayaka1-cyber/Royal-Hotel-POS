import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.tsx';
import { POSProvider } from './context/POSContext.tsx';
import { LoginScreen } from './components/auth/LoginScreen.tsx';
import { Navbar } from './components/layout/Navbar.tsx';
import { POSScreen } from './components/pos/POSScreen.tsx';
import { AdminLayout } from './components/admin/AdminLayout.tsx';
import { Loader2 } from 'lucide-react';

const AppContent: React.FC = () => {
  const { user, isLoading } = useAuth();
  const [currentView, setCurrentView] = useState<'pos' | 'admin'>('pos');

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-900 text-white">
        <div className="flex flex-col items-center gap-3">
          <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
          <span className="text-sm font-semibold tracking-wide">Starting Royal Green POS System...</span>
        </div>
      </div>
    );
  }

  if (!user) {
    return <LoginScreen />;
  }

  // If cashier, enforce POSScreen only
  const isSuperAdmin = user.role === 'super_admin';
  const effectiveView = isSuperAdmin ? currentView : 'pos';

  return (
    <POSProvider>
      <div className="h-screen w-screen flex flex-col overflow-hidden bg-slate-100 dark:bg-slate-950 font-sans">
        {/* Top Global Bar */}
        <Navbar
          currentView={effectiveView}
          onSwitchView={view => setCurrentView(view)}
        />

        {/* Dynamic View Body */}
        <div className="flex-1 flex overflow-hidden">
          {effectiveView === 'pos' ? (
            <POSScreen />
          ) : (
            <AdminLayout onSwitchToPOS={() => setCurrentView('pos')} />
          )}
        </div>
      </div>
    </POSProvider>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
